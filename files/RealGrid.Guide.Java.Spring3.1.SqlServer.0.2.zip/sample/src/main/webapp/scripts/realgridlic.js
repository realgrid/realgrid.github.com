var realGridLic = 
	"upVcPE+wPOnB8WIkZ2gmsypPN9+vaOMYDUkWbkEJahNSClVftxSavsS/Ob2yaOICc6qfV6+Lrno9pWaVkWs2B5PEXRRIuB5C";