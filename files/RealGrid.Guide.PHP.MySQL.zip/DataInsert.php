<?php
$json = file_get_contents('php://input');
$jData = json_decode($json, true);

$db=mysql_connect("localhost", "root", "apmsetup") or die('Could not connect');
mysql_select_db("mysql", $db) or die('');

mysql_query("INSERT INTO products (code, productname, volume, unit, price) 
             VALUES ('".$jData['code']."','".$jData['productname']."','".$jData['volume']."','"
			           .$jData['unit']."','".$jData['price']."')") or die(mysql_error());			

mysql_close($db);

echo $json;
?> 






