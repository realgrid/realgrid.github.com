var realGridLic = 
	"upVcPE+wPOnB8WIkZ2gmsypPN9+vaOMYDUkWbkEJahNSClVftxSavsS/Ob2yaOICc6qfV6+Lrnr2CRLz8EcF88M8YkbgtqFHmN5xIimM6aU=";