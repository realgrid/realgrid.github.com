<?php
$json = file_get_contents('php://input');
$jData = json_decode($json, true);

$db= new PDO('mysql:host=127.0.0.1;dbname=mysql;', 'root', 'apmsetup'); 
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$db->beginTransaction();
try {
	for ($i = 0; $i < sizeof($jData); $i++) {	
		if ($jData[$i]['state'] == 'created') {	
			$db->exec("INSERT INTO products (code, productname, volume, unit, price) 
                       VALUES ('".$jData[$i]['code']."','".$jData[$i]['productname']."','".$jData[$i]['volume']."','"
			                     .$jData[$i]['unit']."','".$jData[$i]['price']."') ");		
		}						  
        else if ($jData[$i]['state'] == 'updated') {	
			$db->exec("UPDATE products
						  SET productname = '".$jData[$i]['productname']."'
							, volume      = '".$jData[$i]['volume']."'
							, unit        = '".$jData[$i]['unit']."' 
							, price       = '".$jData[$i]['price']."'
						WHERE code        = '".$jData[$i]['code']."' ");		
		}						  
        else if ($jData[$i]['state'] == 'deleted') {	
			$db->exec("DELETE FROM products
						WHERE code        = '".$jData[$i]['code']."' ");		
		}						  	
	}
    $db->commit();	
} catch (PDOException $e) {    
    $db->rollback();
	echo "Error: ".$e->getMessage()." ";
}
?> 
