<?php
$json = file_get_contents('php://input');
$jData = json_decode($json, true);

$db=mysql_connect("localhost", "root", "apmsetup") or die('Could not connect');
mysql_select_db("mysql", $db) or die('');

mysql_query("DELETE
               FROM products
			  WHERE code        = '".$jData['code']."' ");

mysql_close($db);

echo $json;
?> 






