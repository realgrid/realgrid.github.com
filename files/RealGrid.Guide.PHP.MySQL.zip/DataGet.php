<?php

$db=mysql_connect("localhost", "root", "apmsetup") or die('Could not connect');
mysql_select_db("mysql", $db) or die('');

$return_array = array();
$result = mysql_query("SELECT * from products") or die('Could not query');

while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	$row_array['code'] = $row['code'];
	$row_array['productname'] = $row['productname'];
	$row_array['volume'] = $row['volume'];
	$row_array['unit'] = $row['unit'];
	$row_array['price'] = $row['price'];
	
	array_push($return_array, $row_array);	
}

echo json_encode($return_array);

mysql_free_result($result);

mysql_close($db);
?>