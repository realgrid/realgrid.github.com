var realGridLic = 
	"upVcPE+wPOnB8WIkZ2gmsypPN9+vaOMYDUkWbkEJahNSClVftxSavsS/Ob2yaOICc6qfV6+LrnrhleB10SfFamvKVoAW6B1t";