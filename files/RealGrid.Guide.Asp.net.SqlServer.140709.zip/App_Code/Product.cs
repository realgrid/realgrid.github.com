﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Product의 요약 설명입니다.
/// </summary>
public class Product
{
    public string Code;
    public string ProductName;
    public string Volume;
    public string Unit;
    public int Price;
}